$(document).ready(function(){
	$(".toggle img").click(function(){
		$(".menu").slideToggle();
	});
});