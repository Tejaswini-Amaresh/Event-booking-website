import requests
from dbconnect import connection

a, config = connection()

def movie_cont(x):
        info = []
        rep=[]
        if len(str((x))) == 7:
            url = 'https://www.omdbapi.com/?i=tt'+str(x)+'&apikey=4081e9d4'

        elif len(str((x))) == 6:
            url = 'https://www.omdbapi.com/?i=tt0' + str(x) + '&apikey=4081e9d4'


        elif len(str((x))) == 5:
            url = 'https://www.omdbapi.com/?i=tt00' + str(x) + '&apikey=4081e9d4'

        elif len(str((x))) == 4:
            url = 'https://www.omdbapi.com/?i=tt000' + str(x) + '&apikey=4081e9d4'


        elif len(str((x))) == 3:
            url = 'https://www.omdbapi.com/?i=tt000' + str(x) + '&apikey=4081e9d4'

        response = requests.get(url)
        if response.json()['Response'] == "True":
            '''results = response.json()['Plot']
            genre = response.json()['Genre']
            poster = response.json()['Poster']
            runtime = response.json()['Runtime']
            title = response.json()['Title']'''


            #info.append((results, genre, runtime, poster,title))
            r=response.json()
            del r['Poster']
            del r['Ratings']
            del r['Metascore']
            del r['imdbRating']
            del r['imdbVotes']
            del r['imdbID']
            del r['Website']
            del r['Type']
            del r['DVD']
            del r['BoxOffice']
            del r['Production']
            del r['Awards']
            del r['Writer'] 
            del r['Response']
            rep.append(r)


        else:
            return x

        return rep



def movie_info(x):
        info = []
        rep=[]
        if len(str((x))) == 7:
            url = 'https://www.omdbapi.com/?i=tt'+str(x)+'&apikey=4081e9d4'

        elif len(str((x))) == 6:
            url = 'https://www.omdbapi.com/?i=tt0' + str(x) + '&apikey=4081e9d4'


        elif len(str((x))) == 5:
            url = 'https://www.omdbapi.com/?i=tt00' + str(x) + '&apikey=4081e9d4'

        elif len(str((x))) == 4:
            url = 'https://www.omdbapi.com/?i=tt000' + str(x) + '&apikey=4081e9d4'


        elif len(str((x))) == 3:
            url = 'https://www.omdbapi.com/?i=tt000' + str(x) + '&apikey=4081e9d4'

        response = requests.get(url)
        if response.json()['Response'] == "True":
            results = response.json()['Plot']
            genre = response.json()['Genre']
            poster = response.json()['Poster']
            runtime = response.json()['Runtime']
            title = response.json()['Title']


            info.append((results, genre, runtime, poster,title))
           


        else:
            return x

        return info


# print(movie_info(1375666))